$RTL =  "../rtl/axi_slave.sv";
$INTER = "../rtl/interface.sv";
$INC =  "+incdir+../wr_agent_top +incdir+../rd_agent_top  +incdir+../test  +incdir+../tb" ;
$PKG =   "../test/axi_test_pkg.sv";
$TOP =  "../tb/top.sv";

print("\t Going to start axi simulation\n\n");

print("Do you want to clean the log files? 'y' or 'n' \n\n");
$CLEAN = <STDIN>;
chomp($CLEAN);
if($CLEAN eq 'y')
	{
	system "rm -rf INCA_libs ncsim.shm open.shm irun.log irun.history *.shmi  irun.key cov_work imc.log mdv.log *.err  *.diag dump.*";
	}

print("Do you want to clear the command window? 'y' or 'n' \n\n");
$CLEAR = <STDIN>;
chomp($CLEAR);
if($CLEAR eq 'y')
	{
	system "clear all";
	system "clear all";
	}

print("test name = \n\n");
$TEST=<STDIN>;
chomp($TEST);

print("Do you want to start the test? 'y' or 'n' \n\n");
$SIM = <STDIN>;
chomp($SIM);
if($SIM eq 'y')
	{
	system "irun -uvm -sv -access +rwc +nccoverage+all -covoverwrite $INTER $PKG $RTL  $INC  $TOP +UVM_RESOURCE_DB_TRACE -timescale 1ns/1ps  +UVM_TESTNAME=$TEST ";
	}

print("Do you want to start the test with gui? 'y' or 'n' \n\n");
$SIM1 = <STDIN>;
chomp($SIM1);
if($SIM1 eq 'y')
	{
	system "irun -uvm -sv -access +rwc -gui $INTER $PKG $RTL  $INC  $TOP +UVM_RESOURCE_DB_TRACE -timescale 1ns/1ps  +UVM_TESTNAME=$TEST ";
	}

print("Do you want to check the wave form? 'y' or 'n' \n\n");
$SIMVISION = <STDIN>;
chomp($SIMVISION);
if($SIMVISION eq 'y')
	{
	system "simvision &";
	}

