# AHB_APB-Bridge
This is normal basic UVM testbench for AMBA Bridge AHB_APB. Please add your own RTL, if you want my RTL it will updated soon.I haven't written testcases if interested please avoid early termination with retry and split responses and give enough delay between two transactions. Enter your own scoreboard according to your wish or I will be updating it soon.
